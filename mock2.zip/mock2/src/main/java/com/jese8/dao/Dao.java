package com.jese8.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.jese8.dto.Dto;

@Component
public class Dao {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();

	public void insert(Dto dto) {
		entityTransaction.begin();
		entityManager.persist(dto);
		entityTransaction.commit();
	}

	public void update(int id, String pwd, long number) {
		Dto dto = entityManager.find(Dto.class, id);
		dto.setPwd(pwd);
		dto.setNumber(number);

		entityTransaction.begin();
		entityManager.merge(dto);
		entityTransaction.commit();
	}

	public void delete(int id) {
		Dto dto = entityManager.find(Dto.class, id);

		entityTransaction.begin();
		entityManager.remove(dto);
		entityTransaction.commit();
	}

	public Dto fetch(int id) {
		Dto dto = entityManager.find(Dto.class, id);
		return dto;
	}

	public List<Dto> fetchAll() {
		Query query = entityManager.createQuery("select data from Dto data");
		List<Dto> list = query.getResultList();
		return list;
	}
}
