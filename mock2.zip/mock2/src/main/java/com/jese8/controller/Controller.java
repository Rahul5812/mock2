package com.jese8.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jese8.dao.Dao;
import com.jese8.dto.Dto;

@org.springframework.stereotype.Controller
public class Controller {
	@Autowired
	Dto dto;
	
	@Autowired
	Dao dao;
	
	@RequestMapping("/insert")
	public ModelAndView create() {
		ModelAndView andView = new ModelAndView("insert.jsp");
		andView.addObject("key", dto);
		return andView;
	}
	
	@ResponseBody
	@RequestMapping("/insert1")
	public void saveData(Dto dto) {
		dao.insert(dto);
	}
	
	@RequestMapping("/update")
	public ModelAndView update(){
		ModelAndView modelAndView = new ModelAndView("update.jsp");
		modelAndView.addObject("upd", dto);
		return modelAndView;
	}
	
	@ResponseBody
	@RequestMapping("/update1")
	public void updateData(int id, String pwd, long number){
		dao.update(id,pwd,number);
	}
	
	@RequestMapping("/delete")
	public ModelAndView delete(){
		ModelAndView andView = new ModelAndView("delete.jsp");
		andView.addObject("del", dto);
		return andView;
	}
	
	@ResponseBody
	@RequestMapping("/delete1")
	public String deleteData(int id){
		dao.delete(id);
		return "data deleted";
	}
	
	@RequestMapping("/fetch")
	public ModelAndView fetch(){
		ModelAndView andView = new ModelAndView("fetch.jsp");
		andView.addObject("key1", dto);
		return andView;
	}
	
	@ResponseBody
	@RequestMapping("/fetch1")
	public ModelAndView display(int id){
		Dto dto2 = dao.fetch(id);
		ModelAndView andView = new ModelAndView("display.jsp");
		andView.addObject("key2", dto2);
		return andView;
	}
	
	@RequestMapping("/displayall")
	public ModelAndView displayAll(){
		List<Dto> list = dao.fetchAll();
		ModelAndView andView = new ModelAndView("displayall.jsp");
		andView.addObject("displayall", list);
		return andView;
	}
}
